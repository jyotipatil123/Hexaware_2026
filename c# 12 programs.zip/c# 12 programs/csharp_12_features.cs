﻿////////// c# 12 features

////////// C# 12.0 features include:
////////// 1. Primary Constructors: Allows you to define a constructor directly in the class declaration.
////////// 2. Collection Literals: Provides a more concise syntax for initializing collections.
////////// 3. Lambda Expression Improvements: Enhancements to lambda expressions, such as allowing attributes and async lambdas.
////////// 4. Interpolated String Improvements: New features for interpolated strings, such as allowing them to be used in attributes and as constant expressions.
////////// 5. Static Abstract Members in Interfaces: Allows interfaces to declare static abstract members, enabling more flexible design patterns.
////////// 6. Improved Pattern Matching: Enhancements to pattern matching, such as allowing patterns in more contexts and improving the syntax for patterns.
////////// 7. File-Scoped Types: Allows you to declare types that are only accessible within the file they are declared in, improving encapsulation and reducing naming conflicts.
////////// 8. Improved Definite Assignment: Enhancements to the definite assignment rules, allowing for more flexible code while still ensuring safety.
////////// These features aim to improve the expressiveness, readability, and maintainability of C# code, making it easier for developers to write clean and efficient code.


////////using System;

////////public class Person(string firstName, string lastName)
////////{
////////    public string FirstName { get; } = firstName;
////////    public string LastName { get; } = lastName;
////////}


////////class Program
////////{
////////    static void Main()
////////    {
////////        Person p1= new Person("John", "Doe");
////////        Console.WriteLine(p1);

////////        //or

////////        var person = new Person("John", "Doe");
////////        Console.WriteLine($"Hello, {person.FirstName} {person.LastName}!");
////////    }
////////}


//////// collection initializer

//////using System;
//////using System.Collections.Generic;
//////using System.Collections;

//////class Program
//////{
//////    static void Main()
//////    {
//////        // collection initializer
//////        var numbers = new List<int> { 1, 2, 3, 4, 5 };
//////        Console.WriteLine(string.Join(", ", numbers));

//////        // collections in .net ==> arrays, arraylist, stack, queue, ..........

//////        List<string> names = new List<string> { "Alice", "Bob", "Charlie" };
//////        Console.WriteLine("List items(string) are : ");
//////        foreach (var name in names)
//////        {
//////            Console.WriteLine(name);
//////        }

//////        Console.WriteLine("List item(ints) are : ");
//////        List<int> ages = new List<int> { 25, 30, 35 };
//////        foreach (var age in ages)
//////        {
//////            Console.WriteLine(age);
//////        }


//////    }
//////}


//////  Generics in C#

////// generic classes demo

////using System;

////class GenericClass<T>
////{
////    public T myvalue { get; set; }
////    public GenericClass(T value)
////    {
////        myvalue = value;
////    }
////    public void Display()
////    {
////        Console.WriteLine($"Value: {myvalue}");
////    }
////}

////class mainclass
////{
////    static void Main(string[] args)
////    {
////        GenericClass<int> intObj = new GenericClass<int>(42);
////        intObj.Display();

////        GenericClass<string> intObj1 = new GenericClass<string>("mysore");
////        intObj1.Display();

////        GenericClass<char> intObj2 = new GenericClass<char>('a');
////        intObj2.Display();

////    }
////}

//// generic methods demo

//using System;

//class genericMethodDemo
//{
//    public void Swap<T>(ref T a, ref T b)
//    {
//        T temp = a;
//        a = b;
//        b = temp;
//    }
//}
//class mainclass
//{
//    static void Main(string[] args)
//    {
//        genericMethodDemo demo = new genericMethodDemo();
//        int x = 10;
//        int y = 20;
//        demo.Swap<int>( ref x, ref y );
//        Console.WriteLine("x="+x);
//        Console.WriteLine("y="+y);

//    }
//}