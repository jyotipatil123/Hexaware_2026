﻿////// Properties in c#
////// Properties are members that provide a flexible mechanism to read,
////// write, or compute the values of private fields.
////// They are special methods called accessors.
////// The get accessor returns the property value, and the set accessor
////// assigns a new value. Properties can be used as if they are public data
////// members, but they are actually special methods called accessors.
////// This allows for data encapsulation and validation when setting values.

////using System;

////namespace Console_Hexaware_demo1
////{
////    class employee
////    {
////        private int empid;

////        private string empname;

////        public int Empid
////        {
////            get { return empid; }
////            set { empid = value; }
////        }
////        public string Empname
////        {
////            get { return empname; }
////            set { empname = value; }
////        }
////    }

////     class Properties_demo
////    {
////        static void Main(string[] args)
////        {
////            employee emp = new employee();
////            emp.Empid = 101;
////            emp.Empname = "John Doe";
////            Console.WriteLine("Employee ID: " + emp.Empid);
////            Console.WriteLine("Employee Name: " + emp.Empname);


////        }
////    }
////}



////using System;namespace CSharp_Learning
////{
////    class Customer
////    {
////        private int custid;
////        private string custname;
////        private int custsalary;
////        public int Custid
////        {
////            get { return custid; }
////            set { custid = value; }
////        }
////        public string Custname
////        {
////            get { return custname; }
////            set { custname = value; }
////        }
////        public int Custsalary
////        {
////            get { return custsalary; }
////            set { custsalary = value; }
////        }
////    }
////    class Properties_demo
////    {
////        static void Main(string[] args)
////        {
////            Customer c = new Customer();
////            c.Custid = 108;
////            c.Custname = "Lipon";
////            c.Custsalary = 100000;
////            Console.WriteLine("Customer ID: " + c.Custid);
////            Console.WriteLine("Customer Name: " + c.Custname);
////            Console.WriteLine("Customer Salary: " + c.Custsalary);

////        }
////    }
////}


////===========================================================================
//// only get --read only property
//// only set --write only property
//// get, set --read and write property
//// inside get ....code to return value
//// inside set ....code to assign value
//// get;set; -- auto implemented property

//using System;

//class employee
//{
//    public string na;
//    public int empid   //read only
//    { get; }

//    public string name   //write only 
//    {
//        set
//        {
//            na = value;
//        }
//    }

//    public string city   // read and write property
//    {
//        get;set;  //auto implemented property
//    }

//    public employee()
//    {
//        empid = 101;
//    }
//}
//class myclass
//{
//    static void Main(string[] args)
//    {
//        // read only property
//        employee e1 = new employee();
//       Console.WriteLine(e1.empid);

//        // write only property
//        e1.name = "Pooja";
//       Console.WriteLine(e1.name);  //error....

//        // read and write property
//        e1.city = "Pune";
//        Console.WriteLine(e1.city);
//    }
//}