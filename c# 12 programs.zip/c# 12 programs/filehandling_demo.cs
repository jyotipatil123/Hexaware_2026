﻿////// file handling in C#
////using System;


////namespace Console_Hexaware_demo1
////{
////     class filehandling_demo
////    {
////        static void Main(string[] args)
////        {
////            FileInfo f1 = new FileInfo("C:\\dummy\\myfile1234.txt");

////            // //or
////            ////  FileInfo f1 = new FileInfo(@"C:\dummy\myfile.txt");

////            //  if (f1.Exists)
////            //   {
////            //      Console.WriteLine("File exists");
////            //   }
////            //   else
////            //   {
////            //      Console.WriteLine("File does not exist");
////            //  }

////            //Console.WriteLine("file full name is : "+f1.FullName);
////            //Console.WriteLine("file last access time : "+ f1.LastAccessTime);
////            //Console.WriteLine("File length is : "+f1.Length);
////            //Console.WriteLine("File creation time is : "+ f1.CreationTime);
////            //Console.WriteLine("File is present in this directory : "+f1.DirectoryName);
////            //Console.WriteLine("file extension is : "+ f1.Extension);

////            //DirectoryInfo d1 = new DirectoryInfo("C:\\dummy");
////            //if (d1.Exists)
////            //{
////            //    Console.WriteLine("Directory exists");
////            //}
////            //else
////            //{
////            //    Console.WriteLine("Directory does not exist");
////            //    Console.WriteLine(d1.FullName);
////            //    Console.WriteLine(d1.CreationTime);
////            //    Console.WriteLine(d1.LastAccessTime);
////            //    Console.WriteLine(d1.Parent);
////            //    Console.WriteLine(d1.Root);

////            //DriveInfo dr1 = new DriveInfo("C");
////            //    Console.WriteLine(dr1.AvailableFreeSpace);
////            //    Console.WriteLine(dr1.DriveFormat);
////            //    Console.WriteLine(dr1.DriveType);
////            //    Console.WriteLine(dr1.IsReady);
////            //    Console.WriteLine(dr1.Name);


////            // read from the file 
////            StreamReader sr = new StreamReader("C:\\dummy\\myfile.txt");
////            string line;

////            while ((line = sr.ReadLine()) != null)
////            {
////                Console.WriteLine(line);
////            }
////             sr.Close();

////             // write to the file 
////             StreamWriter sw = new StreamWriter("C:\\dummy\\myfile.txt");
////             sw.WriteLine("This is a new line added to the file.");
////             sw.Close();



////        }
////    }
////}




//using System.IO;

//class Exercise
//{
//    static void Main(string[] args)
//    {        //creating a new file string path= @"C:\\Users\\DELL\\OneDrive\\Attachments\\Desktop\\hexaware1.txt";
//        FileInfo nf = new FileInfo(path);
//        if (!nf.Exists)
//        {
//            Console.WriteLine("File does not exist, creating a new one..");
//            nf.Create().Close();
//            Console.WriteLine(nf.FullName);
//        }             
//        //writing to the fileConsole.WriteLine("Writing to the file...");
//        StreamWriter sw = new StreamWriter(path);
//        sw.WriteLine("This is a new file created for the exercise.");
//        sw.WriteLine("Adding some more content to the file.");
//        sw.Close();

//        //reading from the fileConsole.WriteLine("Reading from the file...");
//        StreamReader sr = new StreamReader(path);
//        string line;
//        while ((line = sr.ReadLine()) != null)
//        {
//            Console.WriteLine(line);
//        }
//        sr.Close();
//    }
//}
