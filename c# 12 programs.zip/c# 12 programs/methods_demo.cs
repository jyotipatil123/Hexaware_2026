﻿//////// methods demo
//////using System;


//////namespace Console_Hexaware_demo1
//////{
//////    internal class methods_demo
//////    {
//////        static void Main(string[] args)
//////        {
//////            //methods_demo obj = new methods_demo();
//////            //obj.fuction1();

//////            //function2();

//////            myclass m1= new myclass();
//////            m1.fuction1();      

//////        }
//////    }

//////    class myclass
//////    {
//////        public void fuction1()
//////        {
//////            Console.WriteLine("This is function 1");
//////            function2();
//////             function3();   
//////        }

//////        static void function2()
//////        {
//////            Console.WriteLine("This is function 2");
//////        }
//////         void function3()
//////        {
//////            Console.WriteLine("This is function 3");
//////        }
//////    }
//////}


////// value types and reference types demo

////using System;

////class program
////{
////    static void Main(string[] args)
////    {
////        Console.WriteLine("Value types demo");
////        int a = 10;
////        int b = a; // value type assignment
////        Console.WriteLine(b); // Output: 10

////        Console.WriteLine("reference types demo");
////        int[] arr1 = { 1, 2, 3 };
////        int[] arr2 = { 1, 2, 3 };


////        arr2 = arr1; // reference type assignment
////        arr2[0] = 10; // Modifying arr2 will affect arr1
////        Console.WriteLine(arr1[0]); // Output: 10
////    }
////}


//// constants 
//using System;

//class program
//{
//    static void Main(string[] args)
//    {
//        const double pi = 3.14; // constant declaration
//        Console.WriteLine(pi); // Output: 3.14
//                               // pi = 3.14159; // This will cause a compile-time error because pi is a constant

//        pi = 5;
//        // This will also cause a compile-time error because pi is a constant and cannot be reassigned

//        Console.WriteLine(Math.PI);
//    }
//}