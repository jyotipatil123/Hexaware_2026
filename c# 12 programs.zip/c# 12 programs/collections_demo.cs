﻿//// collection demo
//using System;
//using System.Collections;

//namespace Console_Hexaware_demo1
//{
//    internal class collections_demo
//    {
//        static void Main(string[] args)
//        {
//            //   Stack s = new Stack();  //LIFO
//            //   s.Push(10);
//            //   s.Push(20);
//            //   s.Push(30);
//            //   s.Push(40);          

//            //   Console.WriteLine("Stack elements:");
//            //   foreach (var item in s)
//            //   {
//            //       Console.WriteLine(item);
//            //   }

//            //   Console.WriteLine("stack top  : "+ s.Peek());

//            //   s.Pop();
//            //   Console.WriteLine("After pop Stack elements:");
//            //   foreach (var item in s)
//            //   {
//            //       Console.WriteLine(item);
//            //   }

//            //   Console.WriteLine("stack top  : " + s.Peek());
//            ////   s.Clear();
//            ///


//            // queue demo
//            //Queue q = new Queue();  //FIFO   first in first out
//            //q.Enqueue(10);
//            //q.Enqueue(20);
//            //q.Enqueue(30);
//            //q.Enqueue(40);

//            //Console.WriteLine("Queue elements:");
//            //foreach (var item in q)
//            //{
//            //    Console.WriteLine(item);
//            //}

//            //Console.WriteLine("queue front  : " + q.Peek());
//            //q.Dequeue();

//            //Console.WriteLine("After Dequeue Queue elements:");
//            //foreach (var item in q)
//            //{
//            //    Console.WriteLine(item);
//            //}


//            //ArrayList al = new ArrayList();
//            //al.Add(10);
//            //al.Add("Hello");
//            //al.Add(3.14);
//            //al.Add(true);

//            //// var -- implicitly typed local variable

//            //foreach (var item in al)
//            //{
//            //    Console.WriteLine(item);
//            //}

//            //al.Remove(3.14);
//            //Console.WriteLine("After removing 3.14:");
//            //foreach (var item in al)
//            //{
//            //    Console.WriteLine(item);
//            //}
//            ////===================================================
//            //al.RemoveAt(1);   // the index of the element to be removed
//            //Console.WriteLine("After removing the value at 1 index:");
//            //foreach (var item in al)
//            //{
//            //    Console.WriteLine(item);
//            //}

//            //al.RemoveRange(0, 2);  // the index of the first element to be removed and the number of elements to remove

//            //Console.WriteLine("After removing the value at 1 index:");
//            //foreach (var item in al)
//            //{
//            //    Console.WriteLine(item);
//            //}

//            Hashtable h1 = new Hashtable();
//            h1.Add("name", "John");
//            h1.Add("age", 30);

//            Console.WriteLine("Hashtable elements:");
//            foreach (DictionaryEntry item in h1)
//            {
//                Console.WriteLine($"{item.Key} : {item.Value}"); //2nd way

//                Console.WriteLine(item.Key + "  " + item.Value); //1st way

//                Console.WriteLine("{0} {1}", item.Key, item.Value); //3rd way
//            }

//            h1.Remove("age");
//            Console.WriteLine("After removing age:");
//            foreach (DictionaryEntry item in h1)
//            {
//                Console.WriteLine($"{item.Key} : {item.Value}"); //2nd way
//            }
//            h1.Clear();
//            Console.WriteLine("Hash table count is : " + h1.Count);

//            // sorted list demo

//            Console.WriteLine("sorted list demo :");
//            SortedList sl = new SortedList();

//            sl.Add("name", "Alice");
//            sl.Add("age", 25);
//            sl.Add("city", "New York");
//            sl.Add("country", "USA");

//            Console.WriteLine("SortedList elements:");

//            foreach (DictionaryEntry item in sl)
//            {
//                Console.WriteLine($"{item.Key} : {item.Value}");
//            }

//           // SortedList sl1= new SortedList();
//            Hashtable sl1= new Hashtable();
//            sl1.Add("anitha", 10);
//            sl1.Add ("sneha", 30);
//            sl1.Add  ("shruti", 20);
//            sl1.Add("Bob", 40);

//            Console.WriteLine("SortedList elements:");

//            foreach (DictionaryEntry item in sl1)
//            {
//                Console.WriteLine($"{item.Key} : {item.Value}");
//            }

//        }
//    }
//}
