﻿////////// OOPS demo in C# 12.0


////////using System;

////////class company
////////{
////////    public void companydetails()
////////    {
////////        Console.WriteLine("This is company class");
////////    }
////////}

////////class employee : company  // singele inheritance
////////{
////////    public void display()
////////    {
////////        Console.WriteLine("This is employee class");
////////    }
////////}

////////class project : company             // hierarchical  inheritance xxxxxx
////////{
////////    public void projectdetails()
////////    {
////////        Console.WriteLine("This is project class");
////////    }
////////}

//////////class project : company, employee             // mulitple  inheritance xxxxxx
//////////{
//////////    public void projectdetails()
//////////    {
//////////        Console.WriteLine("This is project class");
//////////    }
//////////}


//////////class project : employee             // multilevel inheritance
//////////{
//////////    public void projectdetails()
//////////    {
//////////        Console.WriteLine("This is project class");
//////////    }
//////////}

////////class oops_demo
////////{
////////    static void Main(string[] args)
////////    {
////////        //// single level inheritance demonstration
////////        //employee emp = new employee();

////////        //emp.companydetails();
////////        //emp.display();

////////        // multilevel inheritance demonstration
////////        project proj = new project();
////////        proj.companydetails();
////////        proj.display();
////////        proj.projectdetails();
////////    }
////////}

//////// abstraction 
//////// hide the data 
//////// Car -salesman - customer

//////// encapsulation 
////////  capsule --datas + methods  eg : class 

//////// polymorphism -- poly= many  morph= forms
//////// 1. compile time polymorphism -- method overloading
//////// 2. runtime polymorphism -- method overriding


////////method overloading
//////// one method name with different parameters

//////using System;

//////class calculator
//////{
//////    public void add(int a, int b)
//////    {
//////        Console.WriteLine("Addition of two numbers: " + (a + b));
//////    }
//////    public void add(int a, int b, int c)
//////    {
//////        Console.WriteLine("Addition of three numbers: " + (a + b + c));
//////    }
//////}

//////class program
//////{
//////    static void Main(string[] args)
//////    {
//////        calculator calc = new calculator();
//////        calc.add(10, 20);
//////        calc.add(10, 20, 30);


//////    }
//////}


//////==========================================================================

////// method overriding
////using System;

////class company
////{
////    public virtual void companydetails()
////    {
////        Console.WriteLine("This is company class");
////    }
////}

////class employee : company  // singele inheritance
////{
////    public override void companydetails()
////    {
////        Console.WriteLine("This is employee class");
        
////        base.companydetails();  // calling the base class method
////                                // 
////        //company c1= new company();
////        //c1.companydetails();  // calling the base class method using object of base class
////    }
////}


////class oops_demo
////{
////    static void Main(string[] args)
////    {
////        employee emp = new employee();
////        emp.companydetails();

       
////    }
////}


////=============================================================
//// methods 

//using System;

//// method with return statement
//class calculator
//{
//    public int add(int a, int b)
//    {
//        return a + b;
//    }
//    public int add(int a, int b, int c)
//    {
//        return a + b + c;
//    }
//}

//class mainclass
//{
//    static void Main(string[] args)
//    {
    
//        calculator calc = new calculator();

//        int result1 = calc.add(10, 20);
        
//        int result2 = calc.add(10, 20, 30);
        
//        Console.WriteLine("Addition of two numbers: " + result1);
//        Console.WriteLine("Addition of three numbers: " + result2);
//    }
//}