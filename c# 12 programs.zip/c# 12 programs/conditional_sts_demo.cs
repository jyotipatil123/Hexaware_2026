﻿////// conditional statements in c#
////// if, if-else, nested if, switch-case, ternary operator    

////using System;

////namespace Console_Hexaware_demo1
////{
////    internal class conditional_sts_demo
////    {
////      static void Main(string[] args)
////        {
////            // if-else condition
////            //int a = 100;
////            //if(a > 50)
////            //{
////            //    Console.WriteLine("a is greater than 50");
////            //}
////            //else
////            //{
////            //    Console.WriteLine("a is less than or equal to 50");
////            //}

////            //// only if condition
////            //if (a == 100)
////            //{
////            //    Console.WriteLine("welcome to hexaware");
////            //}

////            // nested if condition

////            int marks = 85;

////            if (marks >= 90)
////            {
////                Console.WriteLine("Grade: A");
////            }
////            else if (marks >= 80)
////            {
////                Console.WriteLine("Grade: B");
////            }
////            else if (marks >= 70)
////            {
////                Console.WriteLine("Grade: C");
////            }
////            else
////            {
////                Console.WriteLine("Grade: F");
////            }
////    }
////}


//// swtich case 

//class Program
//{
//    static void Main(string[] args)
//    {
//        Console.Write("Enter a day of the week (1-7): ");
//        int day = Convert.ToInt32(Console.ReadLine());


//        switch (day)
//        {
//            case 1:
//                Console.WriteLine("Monday");
//                break;
//            case 2:
//                Console.WriteLine("Tuesday");
//                break;
//            case 3:
//                Console.WriteLine("Wednesday");
//                break;
//            case 4:
//                Console.WriteLine("Thursday");
//                break;
//            case 5:
//                Console.WriteLine("Friday");
//                break;
//            case 6:
//                Console.WriteLine("Saturday");
//                break;
//            case 7:
//                Console.WriteLine("Sunday");
//                break;
//            default:
//                Console.WriteLine("Invalid input! Please enter a number between 1 and 7.");
//                break;
//        }
//    }
//}