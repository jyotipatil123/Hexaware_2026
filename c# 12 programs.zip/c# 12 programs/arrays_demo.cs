﻿//////// arrays in c#
//////// stores similar types of datas 

//////using System;


//////namespace Console_Hexaware_demo1
//////{
//////    internal class arrays_demo
//////    {
//////        static void Main(string[] args)
//////        {
//////            //   arrays demo


//////            //int[] arr = new int[5]; // declaration and initialization of array

//////            //// assigning values to array
//////            //arr[0] = 10;
//////            //arr[1] = 20;
//////            //arr[2] = 30;
//////            //arr[3] = 40;
//////            //arr[4] = 50;

//////            //// accessing array elements
//////            //Console.WriteLine("Array elements:");
//////            //for (int i = 0; i < arr.Length; i++)
//////            //{
//////            //    Console.WriteLine(arr[i]);
//////            //}
//////            //==============================================================

//////            //int[] arr = new int[5] {1,2,3,4,5}; // declaration and initialization of array

//////            //// accessing array elements
//////            //Console.WriteLine("Array elements:");
//////            //for (int i = 0; i < arr.Length; i++)
//////            //{
//////            //    Console.WriteLine(arr[i]);
//////            //}


//////            // accept the numbers from user and store in array and print
//////            string[] arr1 = new string[5];

//////            Console.WriteLine("Enter 5 words");

//////            for (int i = 0; i < arr1.Length; i++)
//////            {
//////               arr1[i] = Console.ReadLine();
//////            }

//////            for (int i = 0; i < arr1.Length; i++)
//////            {
//////                Console.WriteLine(arr1[i]);
//////            }
//////        }
//////    }
//////}


////// double dimensional array

//////addition of matrices
////using System;

////class myclass
////{
////    static void Main(string[] args)
////    {
////        Console.WriteLine("Enter the row length : ");
////        int row = Convert.ToInt32(Console.ReadLine());

////        Console.WriteLine("Enter the column length : ");
////        int col = Convert.ToInt32(Console.ReadLine());

////        int [,] arr1 = new int[row, col];

////        Console.WriteLine("Enter the numbers for 1st array :");
////        for (int i = 0; i < row; i++)
////        {
////            for (int j = 0; j < col; j++)
////            {
////                arr1[i, j] = Convert.ToInt32(Console.ReadLine());
////            }
////        }

////        int [,] arr2 = new int[row, col];
////        Console.WriteLine("Enter the numbers for 2nd array :");
////        for (int i = 0; i < row; i++)
////        {
////            for (int j = 0; j < col; j++)
////            {
////                arr2[i, j] = Convert.ToInt32(Console.ReadLine());
////            }
////        }

////        Console.WriteLine("Addition of matrices : ");

////        int[,] result = new int[row, col];
////        for (int i = 0; i < row; i++)
////        {
////            for (int j = 0; j < col; j++)
////            {
////                result[i, j] = arr1[i, j] + arr2[i, j];
////            }
////        }

////        for (int i = 0; i < row; i++)
////        {
////            for (int j = 0; j < col; j++)
////            {
////                Console.WriteLine(result[i, j]);
////            }
////        }

////    }
////}

////===================================================

//// jagged array

//using System;

//class myclass
//{
//    static void Main(string[] args)
//    {
//        int[][] arr = new int[3][];

//        arr[0] = new int[2] { 1, 2 };
//        arr[1] = new int[3] { 3, 4, 5 };
//        arr[2] = new int[4] { 6, 7, 8, 9 };


//        for (int i = 0; i < arr.Length; i++)
//        {
//            for (int j = 0; j < arr[i].Length; j++)
//            {
//                Console.WriteLine(arr[i][j]);
//            }
//        }
//    }
//}   