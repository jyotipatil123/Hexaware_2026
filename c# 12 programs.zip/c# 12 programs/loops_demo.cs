﻿////// loops demo
////// types : for loop, while loop, do while loop, foreach loop
//////loop which helps to execute a block of code repeatedly until a
//////specified condition is met.
//////It is used to perform repetitive tasks without having to
//////write the same code multiple times.

//using System;

//namespace Console_Hexaware_demo1
//{
//    class loops_demo
//    {
//        static void Main(string[] args)
//        {
//            //            //for loop

//            //            Console.WriteLine("for loop demo");
//            //            for (int i = 0; i < 10; i++)
//            //            {
//            //                Console.WriteLine(i);
//            //            }

//            //            //while loop
//            //            Console.WriteLine("while loop demo");
//            //            int j = 0;
//            //            while (j < 10)
//            //            {
//            //                Console.WriteLine(j);
//            //                j++;
//            //            }

//            //            //do while loop
//            //            Console.WriteLine("do while loop demo");
//            //            int k = 0;
//            //            do
//            //            {
//            //                Console.WriteLine(k);
//            //                k++;
//            //            } while (k < 10);

//            // foreach loop demo
//            Console.WriteLine("foreach loop demo");
//            int[] arr = { 1, 2, 3, 4, 5 };
//            foreach (var item in arr)
//            {
//                Console.WriteLine(item);
//            }
//        }
//    }
//}
