﻿// lamda expressions in c# 12
// lamda expressions are anonymous functions that can be used to create
// delegates or expression tree types.
// They are often used in LINQ queries and other scenarios where a
// concise function is needed.
// In C# 12, there are some new features and improvements related to lambda expressions

using System;
using System.Linq;

namespace Console_Hexaware_demo1
{
    class lamda_demo
    {
        static void Main(string[] args)
        {
            // lamda expressions demo

            var numbers = new List<int> { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 };
            var evenNumbers = numbers.Where(n => n % 2 == 0);
            // evenNumbers will contain { 2, 4, 6, 8, 10 }

            Console.WriteLine("Even numbers are : ");

            foreach (var num in evenNumbers)
            {
                Console.WriteLine(num);
            }

            var oddNumbers = numbers.Where(n => n % 2 != 0);
            // oddNumbers will contain { 1, 3, 5, 7, 9 }

            var orderbyNumbers1 = numbers.OrderByDescending(n => n);
            foreach (var item in orderbyNumbers1)
            {
                Console.WriteLine(item);
            }

            var orderbyNumbers2 = numbers.OrderBy(n => n);
            foreach (var item in orderbyNumbers2)
            {
                Console.WriteLine(item);
            }
        }
    }
}