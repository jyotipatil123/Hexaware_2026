﻿//////using System.Threading.Tasks.Sources;

//////namespace Console_Hexaware_demo1
//////{
//////    internal class Program
//////    {
//////        static void Main(string[] args)
//////        {
//////            Console.WriteLine("Hello, World!");
//////            Console.WriteLine("Welcome to Hexaware Technologies!");
//////            Console.Write("use write or writeline do display");
//////        }
//////    }
//////}




//////// core java = c#
///////========================================================================
///////


//////class Program
//////{
//////    static void Main(string[] args)
//////    {
//////        Console.Write("Hello, World!");
//////        Console.Write("Welcome to Hexaware Technologies!");
//////        Console.Write("use write or writeline do display");
//////    }
//////}

//////========================================================================

////// accepting the input from the user

////class Program
////{
////    static void Main(string[] args)
////    {
////        Console.Write("Enter your name: ");

////        string name = Console.ReadLine();

////        Console.WriteLine("Hello, " + name + "!");

////        Console.WriteLine("Enter your rollno : ");
////        int rollno = Convert.ToInt32(Console.ReadLine());
////        Console.WriteLine("Your rollno is : " + rollno);

////    }
////}
////========================================================================

//// calculator program

//class Program
//{
//    static void Main(string[] args)
//    {
//        Console.WriteLine("Enter first number : ");
//        int num1 = Convert.ToInt32(Console.ReadLine());

//        Console.WriteLine("Enter second number : ");
//        int num2 = Convert.ToInt32(Console.ReadLine());

//        Console.WriteLine("Addition result is : " + (num1 + num2));
//        Console.WriteLine("Subtraction result is : " + (num1 - num2));
//        Console.WriteLine("Multiplication result is : " + (num1 * num2));
//        Console.WriteLine("Division result is : " + (num1 / num2));
//        Console.WriteLine("Modulus result is : " + (num1 % num2));



//    }
//}