﻿//// constructors demo
//// A constructor is a special method that is automatically called
//// when an object of a class is created. It is used to initialize
//// the object's properties and set up any necessary resources.
//// Constructors have the same name as the class and do not have
//// a return type, not even void. They can be overloaded, meaning
//// you can have multiple constructors with different parameters to
//// provide different ways of initializing an object.

//// types : copy, static, private,parameterized, default

//// no return type for constructors 

//using System;


//namespace Console_Hexaware_demo1
//{
//    class Person
//    {
//        public Person()  // default construtor
//        {
//            Console.WriteLine("Default constructor called.");
//        }

//        public Person(string name)  // default construtor
//        {
//            Console.WriteLine("Parameterized constructor called."+name);
//        }
//    }
//     class constructors_demo
//    {
//        static void Main(string[] args)
//        {
//            Person p1 = new Person(); // default constructor called
//                                      // 
//            Person p2= new Person("John"); // parameterized constructor called. John

//        }
//    }
//}
