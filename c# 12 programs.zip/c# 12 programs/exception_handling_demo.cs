﻿////// exception handling in c#
////// 1 try -- 1 catch
////// 1 try -- can have multiple catches 
////// only catch...xxxx
////// 1 try...can have 1 finaly()....correct
////// only try xxxxx

////using System;

////namespace Console_Hexaware_demo1
////{
////    class exception_handling_demo
////    {
////        static void Main(string[] args)
////        {
////            try
////            {
////                Console.WriteLine("Enter first number : ");
////                int num1 = Convert.ToInt32(Console.ReadLine());

////                Console.WriteLine("Enter second number : ");
////                int num2 = Convert.ToInt32(Console.ReadLine());

////                int result = num1 / num2;

////                Console.WriteLine("Division result is : " + result);
////            }

////            catch(DivideByZeroException ex)
////            {
////                Console.WriteLine(ex.Message);
////            }
////            catch (Exception ex)
////            {
////                Console.WriteLine(ex.Message);
////            }


////            finally  //optional 
////             {
////                Console.WriteLine("This block will always execute");
////                 // closing all the pointers in the program 
////            }

////        }
////    }
////}


//// user defined exception

//using System;

//namespace Console_Hexaware_demo1
//{
//    class MyException : Exception
//    {
//        public MyException(string message) : base(message)
//        {
//        }
//    }
//    class exception_handling_demo
//    {
//        static void Main(string[] args)
//        {
//            try
//            {
//                Console.WriteLine("Enter your age : ");
//                int age = Convert.ToInt32(Console.ReadLine());

//                if (age < 18)
//                {
//                    throw new MyException("You are not eligible to vote");
//                }
//                else
//                {
//                    Console.WriteLine("You are eligible to vote");
//                }
//            }
//            catch (MyException ex)
//            {
//                Console.WriteLine(ex.Message);
//            }
//            catch (Exception ex)
//            {
//                Console.WriteLine(ex.Message);
//            }
//        }
//    }

//}

////=======================================================================

//class Program
//{
//    public static void Main()
//    {
//        Console.Write("Enter balance: ");
//        double Balance = Convert.ToDouble(Console.ReadLine());
//        try
//        {
//            if (Balance < 0)
//            {
//                throw new Negative("Balance cannot be negative");
//            }
//            else
//            {
//                Console.WriteLine("Balance is: " + Balance);
//            }
//        }
//        catch (Negative ex)
//        {
//            Console.WriteLine("Error: " + ex.Message);
//        }
//    }

//    public class NegativeException : Exception
//    {
//        public Negative(string message) : base(message)
//        {

//        }
//    }
//}
