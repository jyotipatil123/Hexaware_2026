﻿////////// abstract classes 
////////// abstract classes objects can not be created
////////// abstract classes can have abstract and non-abstract methods
////////// abstract classes can have constructors
////////// abstract classes can have fields and properties
////////// abstract classes can have access modifiers

////////// access modifiers : private, public, protected, internal, protected internal, private protected


////////// interfaces


////////using System;

////////namespace Console_Hexaware_demo1
////////{
////////    public abstract class Shape
////////    {
////////        public abstract void Draw(); // Abstract method
////////        public void Display() // Non-abstract method
////////        {
////////            Console.WriteLine("This is a shape.");
////////        }
////////    }

////////    public class Circle : Shape
////////    {
////////        public override void Draw() // Implementing the abstract method
////////        {
////////            Console.WriteLine("Drawing a circle.");
////////        }
////////    }

////////    class abstract_interfaces
////////    {
////////        static void Main(string[] args)
////////        {
////////            Shape s1 = new Circle();  // correct
////////            s1.Draw();
////////            s1.Display();


////////            Circle c1= new Circle();  // correct
////////            c1.Draw();
////////            c1.Display();

////////            // Shape s2 = new Shape();  // incorrect, cannot create an object of an abstract class
////////            // s2.Draw(); // incorrect, cannot call an abstract method
////////            // s2.Display(); // correct, can call a non-abstract method

////////        }
////////    }
////////}


//////// interfaces in c#

//////using System;

//////interface IShape
//////{
//////    void Draw(); // Interface method (implicitly public and abstract)
//////}

//////interface IShape1
//////{ 
//////    public void write();
//////    public void read();
//////}   

//////class myclass : IShape ,IShape1  //implementing the interface
//////{
//////     void IShape.Draw() 
//////    {
//////        Console.WriteLine("Drawing a shape.");
//////    }
//////     void IShape1.write()
//////    {
//////        Console.WriteLine("writing something");
//////    }
//////     void IShape1.read()
//////    {
//////        Console.WriteLine("reading something");
//////    }
//////}

//////class mainclass
//////{
//////    static void Main(string[] args)
//////    {
//////            myclass obj = new myclass();
//////            obj.Draw();
//////            obj.write();
//////            obj.read();
//////    }
//////}

//////interface inheritance 

////using System;

////interface IShape
////{
////    void Draw(); // Interface method (implicitly public and abstract)
////}

////interface IShape1 : IShape   // interaface inheritance, IShape1 inherits from IShape
////{
////    public void write();
////    public void read();
////}

////class myclass : IShape1  //implementing the interface
////{
////    void IShape.Draw()
////    {
////        Console.WriteLine("Drawing a shape.");
////    }
////    void IShape1.write()
////    {
////        Console.WriteLine("writing something");
////    }
////    void IShape1.read()
////    {
////        Console.WriteLine("reading something");
////    }
////}

////class mainclass
////{
////    static void Main(string[] args)
////    {
////        myclass obj = new myclass();
////        obj.Draw();
////        obj.write();
////        obj.read();
////    }
////}

//// sealed keyword in c#

//using System;

//sealed class myclass
//{
//    public void display()
//    {
//        Console.WriteLine("This is a sealed class.");
//    }
//}

//class derivedclass : myclass  // incorrect, cannot inherit from a sealed class
//{
//    public void display()
//    {
//        Console.WriteLine("This is a derived class.");
//    }
//}

//class mainclass
//{
//    static void Main(string[] args)
//    {
//            myclass obj = new myclass();
//        obj.display();
//    }
//}